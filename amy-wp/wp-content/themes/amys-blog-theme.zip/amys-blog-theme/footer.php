<div class="footer-clear"></div>
<footer class="row no-max pad">
  <ul>

    <li>
        <a href="https://www.facebook.com/amygalbraithphotography/">
            <i class="fa fa-facebook" aria-hidden="true"></i>
        </a>
    </li>

    <li>
        <a href="https://twitter.com/amygphoto">
            <i class="fa fa-twitter" aria-hidden="true"></i>
        </a>
    </li>

    <li>
        <a href="https://www.instagram.com/amygphoto/">
            <i class="fa fa-instagram" aria-hidden="true"></i>
        </a>
    </li>

    <li>
        <a href="https://www.pinterest.com/amygphoto/">
            <i class="fa fa-pinterest" aria-hidden="true"></i>
        </a>
    </li>

  </ul>
  <p>Developed for Amy Galbraith Photography &copy; <?php echo date('Y'); ?></p>
</footer>

    <?php wp_footer(); ?>

  </body>
</html>