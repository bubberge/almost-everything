<div class="small-12 large-1 columns">
	
	<div id="amy-prebar">

        <a href="<?php bloginfo('url'); ?>"><img id="amy-prebar-logo" class="prebar-logo" src="<?php header_image(); ?>"></a>

		<ul class="prebar">

			<li>
				<a href="https://www.facebook.com/amygalbraithphotography/">
					<i class="fa fa-facebook" aria-hidden="true"></i>
				</a>
			</li>

			<li>
				<a href="https://twitter.com/amygphoto">
					<i class="fa fa-twitter" aria-hidden="true"></i>
				</a>
			</li>

			<li>
				<a href="https://www.instagram.com/amygphoto/">
					<i class="fa fa-instagram" aria-hidden="true"></i>
				</a>
			</li>

			<li>
				<a href="https://www.pinterest.com/amygphoto/">
					<i class="fa fa-pinterest" aria-hidden="true"></i>
				</a>
			</li>

		</ul>

	</div>

</div>