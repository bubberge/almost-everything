<div class="large-3 show-for-large-up columns">
	
	<?php if ( is_active_sidebar( 'home_right_1' ) ) : ?>
		<div id="amy-widgets" class="navigation" role="complementary">
			<?php dynamic_sidebar( 'home_right_1' ); ?>
		</div><!-- #amy-widgets -->
	<?php endif; ?>

</div>